public class GasPoweredMower extends WalkBehindMower{
    private Engine engine;
    private boolean selfPropelled;

    public GasPoweredMower(){
        this.engine = null;
        this.selfPropelled = false;
    }
    public GasPoweredMower(double cutwidth, double wheeldiameter, Engine engine,  boolean selfPropelled, String manufacturer, int year, String serialNumber){
        setengine(engine);
        setselfPropelled(selfPropelled);
        setmanufaturer(manufacturer);
        setyear(year);
        setSN(serialNumber);
        setcutWidth(cutwidth);
        setwheeldiameter(wheeldiameter);
    }

    public void setengine(Engine engine){
        this.engine = engine;
    }
    public Engine getengine(){
        return engine;
    }
    public void setselfPropelled(boolean selfPropelled){
        this.selfPropelled = selfPropelled;
    }
    public boolean getselfPropelled(){
        return selfPropelled;
    }
    public String toString(){
        return  "Manufacturer: " + getmanufacturer() + " Year: " + getyear() + " Serial Number: " + getSN() + "Engine: " + getengine() + " Self Propelled: " + getselfPropelled() + "Cut Width: " + getcutWidth() + " Wheel Diameter: " + getwheeldiameter();
    }
}


public class CommercialMower extends LawnTractor{
    private double operatingHours;
    private boolean zeroTurnRadius;

    public CommercialMower(){
        this.operatingHours = 0.00;
        this.zeroTurnRadius = false;
    }
    public CommercialMower(Engine engine, String model, double deckWidth, double operatingHours, boolean zeroTurnRadius, String manufacturer, int year, String serialNumber){
        setoperatingHours(operatingHours);
        setzeroTurnRadius(zeroTurnRadius);
        setengine(engine);
        setmodel(model);
        setdeckwidth(deckWidth);
        setmanufaturer(manufacturer);
        setSN(serialNumber);
        setyear(year);
    }
    public void setoperatingHours(double operatingHours){
        this.operatingHours = operatingHours;
    }
    public double getoperatingHours(){
        return operatingHours;
    }
    public void setzeroTurnRadius(boolean zeroTurnRadius){
        this.zeroTurnRadius = zeroTurnRadius;
    }
    public boolean getzeroTurnRadius(){
        return zeroTurnRadius;
    }

    public String toString(){
        return "Manufacturer: " + getmanufacturer() + " Year: " + getyear() + " Serial Number: " + getSN() + getengine() + " Model: " + getmodel() + " Deck Width: " + getdeckWidth() + "Operating Hours: " + getoperatingHours() + " Zero Turn Radius: " + getzeroTurnRadius();
    }
}

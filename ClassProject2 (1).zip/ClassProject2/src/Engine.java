public class Engine {
    String manufacturer;
    double horsepower;
    int cylinders;

    public Engine(){
        this.manufacturer = "";
        this.horsepower = 0.00;
        this.cylinders = 0;
    }
    public Engine(String manufacturer, double horsepower, int cylinders) {
        setman(manufacturer);
        sethrsp(horsepower);
        setcyl(cylinders);
    }
    public void setman(String manufacturer){
        this.manufacturer = manufacturer;}
    public String getman(){
        return manufacturer;
    }
    public void sethrsp(double horsepower){
        this.horsepower = horsepower;}
    public double gethrsp(){
        return horsepower;
    }
    public void setcyl(int cylinders){
        this.cylinders = cylinders;
    }
    public int getcyl(){
        return cylinders;
    }

    public String toString() {
        return "Engine Manufacturer: " + getman() + " Horsepower; " + gethrsp() + " Cylinders: " + getcyl();
    }
    }


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class mowerWarehouse {
    private String storename;
    private ArrayList<mower> mowers;


    public mowerWarehouse() {
        this.storename = "";
        mowers = new ArrayList<>();

    }


    public mowerWarehouse(String storename, ArrayList<mower> mowers) {
        setstorename(storename);
        setmowers(mowers);
    }

    public void setstorename(String storename) {
        this.storename = storename;
    }

    public String getstorename() {
        return storename;
    }

    public void setmowers(ArrayList<mower> mowers) {
        this.mowers = mowers;
    }

    public ArrayList getmowers() {
        return mowers;
    }

    public void readMowerData(String inputFileName){

        try {

            Scanner scnr = new Scanner(new FileReader(inputFileName));
            storename = scnr.nextLine();


            while (scnr.hasNextLine()) {
                String manufacturer = scnr.nextLine();
                int year = Integer.parseInt(scnr.nextLine());
                String serialNumber = scnr.nextLine();
                String mowertype = scnr.nextLine();


                if (mowertype.equals("L")) { // reads the file as a lawn tractor
                    String manu = scnr.nextLine();
                    double hrsp = Double.parseDouble(scnr.nextLine());
                    int cylinders = Integer.parseInt((scnr.nextLine()));
                    String model = scnr.nextLine();
                    double deckWidth = Double.parseDouble(scnr.nextLine());


                    Engine engine = new Engine(manu, hrsp, cylinders);
                    LawnTractor lawn  = new LawnTractor(engine, model ,deckWidth, manufacturer, year, serialNumber);


                    mowers.add(lawn);
                } else if (mowertype.equals("C")) { // reads the file as a commercial mower

                    String manu = scnr.nextLine();
                    double hrsp = Double.parseDouble(scnr.nextLine());
                    int cylinders = Integer.parseInt(scnr.nextLine());


                    String model = scnr.nextLine();
                    double ophrs = Double.parseDouble(scnr.nextLine());
                    double deckw = Double.parseDouble(scnr.nextLine());
                    boolean zeroturn = Boolean.parseBoolean(scnr.nextLine());


                    Engine engine = new Engine(manu, hrsp, cylinders);
                    CommercialMower cm  = new CommercialMower(engine, model ,deckw, ophrs, zeroturn, manufacturer, year, serialNumber);


                    mowers.add(cm);

                } else if (mowertype.equals("G")) { // reads the file as a Gas powered motor

                    double cutw = Double.parseDouble(scnr.nextLine());
                    double wheeldiam = Double.parseDouble(scnr.nextLine());
                    String manu = scnr.nextLine();
                    double hrsp = Double.parseDouble(scnr.nextLine());
                    int cylinders = Integer.parseInt(scnr.nextLine());
                    boolean selfprop =  Boolean.parseBoolean(scnr.nextLine());


                    Engine engine = new Engine(manu, hrsp, cylinders);
                    GasPoweredMower gaspow = new GasPoweredMower(cutw, wheeldiam, engine, selfprop, manufacturer, year, serialNumber);

                    mowers.add(gaspow);


                } else if (mowertype.equals("P")) { // reads the data as a pushreel mower


                    double cutwidth = Double.parseDouble(scnr.nextLine());
                    double wheeld = Double.parseDouble(scnr.nextLine());
                    int wheels = Integer.parseInt(scnr.nextLine());

                    PushReelMower pushreel = new PushReelMower(cutwidth, wheeld, wheels, manufacturer, year, serialNumber);

                    mowers.add(pushreel);


                }

            }
            scnr.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }



    public void saveMowerData(String outputFileName){
        try{
            PrintWriter writer = new PrintWriter(outputFileName);
                for(mower mower: mowers) {
                    writer.println(mower.toString());
                }
                writer.close();
            }
        catch (FileNotFoundException e){
            e.printStackTrace();}

    }
    public String toString() {
        String res = "";
        res = "Store Name: " + storename + "\n";
        for (mower m : mowers) {
            res = res + m.toString() + "\n";
        }
        return res;
    }

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);

        String input = "mowerfile.txt";
        mowerWarehouse newmowers = new mowerWarehouse();

        ArrayList<mower> mower = newmowers.getmowers();

        newmowers.readMowerData(input);
        newmowers.saveMowerData("ouput.txt");
        System.out.println("Type L for LawnTractor, Type C for CommercialMower, Type G for Gaspowered mower, Type P for Pushreelmower");
        String type = scnr.next();
        // outputs the mowers based off of the users input
        while(!(type.equals("S"))){
            if(type.equals("L")){
                for(mower mow: mower){
                    if(mow instanceof LawnTractor){
                        System.out.println(mow.toString());}}}
            if(type.equals("C")){
                for(mower mow: mower){
                    if(mow instanceof CommercialMower){
                        System.out.println(mow.toString());}}}
        if(type.equals("G")){
            for(mower mow: mower){
                if(mow instanceof GasPoweredMower){
                    System.out.println(mow.toString());}}}
        if(type.equals("P")){
            for(mower mow: mower){
                if(mow instanceof PushReelMower){
                    System.out.println(mow.toString());}}}
        type = scnr.next();
            }}
        }











public class LawnTractor extends mower {
    private Engine engine;
    private String model;
    private double deckWidth;

    public LawnTractor(){
        this.engine = null;
        this.model = "";
        this.deckWidth = 0.0;
    }
    public LawnTractor( Engine engine, String model, double deckWidth, String manufacturer, int year, String serialNumber){
        setengine(engine);
        setmodel(model);
        setdeckwidth(deckWidth);
        setmanufaturer(manufacturer);
        setSN(serialNumber);
        setyear(year);
    }
    public void setengine(Engine engine){
        this.engine = engine;
    }
    public Engine getengine(){
        return engine;
    }
    public void setmodel(String model){
        this.model = model;
    }
    public String getmodel(){
        return model;
    }
    public void setdeckwidth(double deckWidth){
        this.deckWidth = deckWidth;
    }
    public double getdeckWidth(){
        return deckWidth;
    }
    public String toString(){
        return "Manufacturer: " + getmanufacturer() + " Year: " + getyear() + " Serial Number: " + getSN() + getengine() + " Model: " + getmodel() + " Deck Width: " + getdeckWidth()+ " Model: " + getmodel() + " Deck Width: " + getdeckWidth();
    }

}

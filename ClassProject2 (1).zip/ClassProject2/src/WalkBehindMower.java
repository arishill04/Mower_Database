public abstract class WalkBehindMower extends mower{
    private double cutWidth;
    private double wheeldiameter;
    public WalkBehindMower(){
        this.cutWidth = 0.00;
        this.wheeldiameter = 0.00;
    }
    public WalkBehindMower(double cutWidth, double wheeldiameter){
        setcutWidth(cutWidth);
        setwheeldiameter(wheeldiameter);
    }
    public void setcutWidth(double cutWidth){
        this.cutWidth = cutWidth;
    }
    public double getcutWidth(){
        return cutWidth;
    }
    public void setwheeldiameter(double wheeldiameter){
        this.wheeldiameter =  wheeldiameter;
    }
    public double getwheeldiameter(){
        return wheeldiameter;
    }
    public String toString(){
    return "Manufacturer: " + getmanufacturer() + " Year: " + getyear() + " Serial Number: " + getSN() + "Cut Width: " + getcutWidth() + " Wheel Diameter: " + getwheeldiameter();}
}

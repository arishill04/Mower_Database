public class PushReelMower extends WalkBehindMower{
    private int numwheels;

    public PushReelMower(){

    }
    public PushReelMower(double cutWidth, double wheeldiameter, int numwheels, String manufacturer, int year, String serialNumber){
        setmanufaturer(manufacturer);
        setyear(year);
        setSN(serialNumber);
        setcutWidth(cutWidth);
        setwheeldiameter(wheeldiameter);
        setnumwheels(numwheels);
    }
    public void setnumwheels(int numwheels){
        this.numwheels = numwheels;
    }
    public int getnumwheels(){
        return numwheels;
    }

    public String toString(){

        return "Manufacturer: " + getmanufacturer() + " Year: " + getyear() + " Serial Number: " + getSN() + "Cut Width: " + getcutWidth() + " Wheel Diameter: " + getwheeldiameter()+ " Number of Wheels: " + getnumwheels();
    }
}

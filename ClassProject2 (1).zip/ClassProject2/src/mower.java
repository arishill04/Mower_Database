public abstract class mower {
    private String manufacturer;
    int year;
    private String serialNumber;

    public mower(){
        this.manufacturer = "";
        this.year = 0;
        this.serialNumber = "";
    }
    public mower(String manufacturer, int year, String serialNumber){
        setmanufaturer(manufacturer);
        setyear(year);
        setSN(serialNumber);
    }
    public void setmanufaturer(String manufacturer){
        this.manufacturer = manufacturer;}
    public String getmanufacturer(){
        return manufacturer;
    }
    public void setyear(int year){
        this.year = year;
    }
    public int getyear(){
        return year;
    }
    public void setSN(String serialNumber){
        this.serialNumber = serialNumber;
    }
    public String getSN(){
        return serialNumber;
    }
    public String toString(){
        return "Manufacturer: " + getmanufacturer() + "\nYear: " + getyear() + "\nSerial Number: " + getSN();
    }
}

public class lawntype {
    String lawntypes;

    public lawntype() {
        lawntypes = "";

    }

    public void setLawntype(String lawntypes) {
        this.lawntypes = lawntypes;
    }
    public String getLawntype(){
        return lawntypes;
    }
}